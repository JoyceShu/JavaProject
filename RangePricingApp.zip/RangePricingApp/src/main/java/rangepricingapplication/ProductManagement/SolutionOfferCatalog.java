/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.ProductManagement;

import java.util.ArrayList;
import rangepricingapplication.Business.Business;
import rangepricingapplication.MarketModel.Channel;
import rangepricingapplication.MarketModel.Market;

/**
 *
 * @author joyce
 */
public class SolutionOfferCatalog {
    Business business;
    Market market;
    ArrayList <SolutionOffer> solutionofferlist;
    Channel channel;
            
    public SolutionOfferCatalog () {
        solutionofferlist = new ArrayList();
        this.business  = business;
        this.channel = channel;
    }

    public SolutionOffer newSolutionOffer(Market m, int p,Channel c) {
        SolutionOffer so = new SolutionOffer(m, p, c);
        solutionofferlist.add(so);
        return so;
    }
    public SolutionReport gernarateSalesReveuneReport(){
        SolutionReport sr = new SolutionReport();
        for (SolutionOffer so: solutionofferlist){
            SoluionOfferSummary sos = new SoluionOfferSummary(so);
            sr.addSolutionOfferSummary(sos);
        }
        return sr;
    }
    
    
    

    /*public void printTotalSalesVolume() {
        for (SolutionOffer so: solutionofferlist){
        so.printSoSaleRevenus();
    }}*/
       
    


    
}
