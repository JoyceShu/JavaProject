/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.ProductManagement;

import java.util.ArrayList;
import java.util.Collections;


/**
 *
 * @author kal bugrara
 */
public class ProductsReport {
    ProductCatalog productcatalog;
    ArrayList<ProductSummary> productsummarylist;
    public ProductsReport(){
           //ProductSummary ps_sv = new ProductSummary();
           //productsummarylist.add(ps_sv);
           //return ps_sv;
    }
    public ProductSummary newProductSummary(Product p) {

        ProductSummary ps = new ProductSummary(p);
        productsummarylist.add(ps);
        return ps;
    }

    public ProductsReport(ArrayList<ProductSummary> productsummarylist) {
        this.productsummarylist = productsummarylist;
    }
    
    public void addProductSummary(ProductSummary ps){
    productsummarylist.add(ps);
}
 
    
    public ProductSummary getTopProductAboveTarget(){
        ProductSummary currenttopproduct = null;
        
        for (ProductSummary ps: productsummarylist){
          if(currenttopproduct == null)currenttopproduct = ps; // initial step 
           else 
             if(ps.getNumberAboveTarget()> currenttopproduct.getNumberAboveTarget()){
             currenttopproduct = ps;             }                        }//we have a new higher total
        return currenttopproduct;
    }

    public void printTopProduct(int numberOfStudent){
        
        productsummarylist.sort(new ProductSummaryComparator());
        for (int i = 0; i < numberOfStudent; i++){
            System.out.println( i + " ." + productsummarylist.get(i).getSubjectproduct().getName() + " | Sales Volume: " + productsummarylist.get(i).getSalesvolume());
        
        }
        //return templist;
        
    }


}

          
         //ArrayList<ProductSummary> templist = new ArrayList();
        //for (ProductSummary ps_sv: productsummarylist){
            //templist.add(ps_sv);
            //ProductSummaryComparator pc = new ProductSummaryComparator();
            //Collections.sort(templist,pc);  productsummarylist.sort(new ProductSummaryComparator());
        
        
        
     
        
    

    

 

