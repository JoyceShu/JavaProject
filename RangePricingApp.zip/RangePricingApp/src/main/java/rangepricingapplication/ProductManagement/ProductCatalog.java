/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.ProductManagement;

import java.util.ArrayList;
import java.util.Random;
import rangepricingapplication.Supplier.Supplier;

/**
 *
 * @author kal bugrara
 */
public class ProductCatalog {
    Supplier supplier;
    ArrayList<Product> products;
    ArrayList<ProductsReport> pr;
    
    public ProductCatalog(Supplier supplier){
        this.supplier = supplier;
        products = new ArrayList();
        pr = new ArrayList();
    }
 
    public Product newProduct(String name,int fp, int cp, int tp){
        Product p = new Product(name, fp, cp, tp);
        products.add(p);
        return p;
    }
    
    public ProductsReport generatPerformanceReport(){
        ProductsReport productsreport = new ProductsReport();
        for(Product p: products){
            ProductSummary ps = new ProductSummary(p);
            productsreport.addProductSummary(ps);
        }
        return productsreport; 
    }  
    
    
     public int getSaleVolme() {
        int sum = 0;
        for (Product p : products) {
            sum = sum + p.getSalesVolume();     //positive and negative values       
        }
        return sum;
    }
    
    public Supplier getSupplier() {
        return supplier;
    }

    public ArrayList<Product> getProducts() {
        return products;
    }
    
    public ArrayList<ProductsReport> getProductReport() {
        return pr;
    }
    
    public void printProducts(){
    for (Product p: products){
        p.printProductsDetails();
    }
    
    
    };
    
    
    public Product getRandomProduct(){
        Product randomProduct;
        Random r = new Random();
        int randomIndex = r.nextInt(products.size());
        randomProduct = products.get(randomIndex);
        return randomProduct;
    }
    
    public void printProductDetailPP(){
        for (Product p: products){
        p.printProductsDetailsPP();
    }
    
    
    }
   
    
    
    


}



