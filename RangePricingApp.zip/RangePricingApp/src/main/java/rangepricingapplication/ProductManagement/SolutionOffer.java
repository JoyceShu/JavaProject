/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.ProductManagement;

import java.util.ArrayList;
import rangepricingapplication.MarketModel.Channel;
import rangepricingapplication.MarketModel.Market;
import rangepricingapplication.OrderManagement.OrderItem;

/**
 *
 * @author kal bugrara
 */
public class SolutionOffer {
    ArrayList<Product> products;
    private int price;
    Market market;
    SolutionOfferCatalog soCatalog;
    Channel channel;
    ArrayList<OrderItem> orderitems;
    int basicPrice;
    
    public SolutionOffer(Market m, int p, Channel c){
        market = m;
        products = new ArrayList();
        price = p;
        channel =c;
        orderitems = new ArrayList();
    }


    public int getPrice() {
        return price;
    }

    public int getBasicPrice() {
        return basicPrice;
    }

    public void setBasicPrice(int basicPrice) {
        this.basicPrice = basicPrice;
    }


    
    public void addOrderItem(OrderItem oi){
        orderitems.add(oi);
    }

    
    public void addProduct(Product p1, Product p2){
        products.add(p1);
        products.add(p2);
    }
 

    public ArrayList<Product> getProducts() {
        return products;
    }
    
    public int getSaleRevenue(){
        int sum = 0;
        for (OrderItem oi: orderitems){
            sum = sum + oi.getOrderItemTotal();
        }
         return sum;
    }
    
    public int getOrderPricePerformance(){
        int sum = 0;
        for (OrderItem oi: orderitems){
            sum = sum + oi.calculatePricePerformance();
        }
         return sum;
    }

    

    public Market getMarket() {
        return market;
    }

    public SolutionOfferCatalog getSoCatalog() {
        return soCatalog;
    }
 
    public SolutionOffer updateSolutionOffer(int p, Market m) {
        price = p;
        market = m;
        return this; //returns itself
    }
    
  

    public void printSolutionOfferDetail() {
        for (Product p: products){
        p.printProductDetail_so();
    }
       
    }

    public Channel getChannel() {
        return channel;
    }



    
}
