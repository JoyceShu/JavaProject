/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.ProductManagement;

import java.util.ArrayList;

/**
 *
 * @author joyce
 */
public class SolutionReport {
    ArrayList<SoluionOfferSummary> Sosummarylist;

    public SolutionReport() {
    }
    
    public void addSolutionOfferSummary(SoluionOfferSummary sos){
        Sosummarylist.add(sos);
    }
    

    
    
}
