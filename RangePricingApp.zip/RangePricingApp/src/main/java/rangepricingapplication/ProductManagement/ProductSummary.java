/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.ProductManagement;

import rangepricingapplication.OrderManagement.OrderItem;

/**
 *
 * @author kal bugrara
 */
//this class will extract summary data from the product
public class ProductSummary {
    Product subjectproduct;
    String name;
    int numberofsalesabovetarget;
    int numberofsalesbelowtarget;
    int salesvolume;
    int salesperformance;
    int rank; // will be done later

    public ProductSummary(Product subjectproduct, String name, int numberofsalesabovetarget, int numberofsalesbelowtarget, int salesvolume, int salesperformance, int rank) {
        this.subjectproduct = subjectproduct;
        this.name = name;
        this.numberofsalesabovetarget = numberofsalesabovetarget;
        this.numberofsalesbelowtarget = numberofsalesbelowtarget;
        this.salesvolume = salesvolume;
        this.salesperformance = salesperformance;
        this.rank = rank;
    }
    
    
    public ProductSummary(Product p){
        //numberofsalesabovetarget = p.getNumberOfProductSalesAboveTarget();
        salesperformance = p.getOrderPricePerformance();
        subjectproduct = p; //keeps track of the product itself not as well;
        salesvolume = p.getSalesVolume();
      
    }

  

    public int getNumberAboveTarget(){
        return numberofsalesabovetarget;
    }

    public Product getSubjectproduct() {
        return subjectproduct;
    }

    public int getNumberofsalesabovetarget() {
        return numberofsalesabovetarget;
    }

    public int getNumberofsalesbelowtarget() {
        return numberofsalesbelowtarget;
    }

    public int getSalesvolume() {
        return salesvolume;
    }

    public int getSalesperformance() {
        return salesperformance;
    }


    public int getRank() {
        return rank;
    }
    

}
