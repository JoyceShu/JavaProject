/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.ProductManagement;

import rangepricingapplication.MarketModel.Channel;

/**
 *
 * @author joyce
 */
public class SoluionOfferSummary {
    SolutionOffer solutionOffer;
    int salesRevenus;
    int pricePerformance;
    Channel channel;

    public SoluionOfferSummary(SolutionOffer so) {
        solutionOffer = so;
        salesRevenus = so.getSaleRevenue();
        pricePerformance = so.getOrderPricePerformance();
        channel = so.getChannel();
        
    }

    public int getSalesRevenus() {
        return salesRevenus;
    }

    public int getPricePerformance() {
        return pricePerformance;
    }


    
}
