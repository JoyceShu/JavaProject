/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.ProductManagement;

import java.util.ArrayList;
import java.util.Random;
import rangepricingapplication.OrderManagement.OrderItem;
import rangepricingapplication.Supplier.Supplier;

/**
 *
 * @author kal bugrara
 */
public class Product {
    ProductCatalog productCatalog;
    String name;
    private int floorPrice;
    private int ceilingPrice;
    private int targetPrice;
    ArrayList<OrderItem> orderitems;
    
    
    public Product(String name, int fp, int cp, int tp) {
        floorPrice = fp;
        ceilingPrice = cp;
        targetPrice = tp;
        orderitems = new ArrayList();
        //productCatalog = pd;
        this.name = name;
    }
        public Product updateProduct(int fp, int cp, int tp) {
        floorPrice = fp;
        ceilingPrice = cp;
        targetPrice = tp;
        return this; //returns itself
    }
    public int getTargetPrice() {return targetPrice;}
   
    public void addOrderItem(OrderItem oi){     
        orderitems.add(oi);
    }
    //Number of item sales above target 
    public int getNumberOfProductSalesAboveTarget(){
        int sum = 0;
        for (OrderItem oi: orderitems){
            if(oi.isActualAboveTarget()==true) sum = sum +1;
        }
        return sum;
    }  

    //calculates the revenues gained or lost (in relation to the target)
    //For example, if target is at $2000 and actual is $2500 then revenue gained
    // is $500 above the expected target. If the actual is $1800 then the lose will be $200
    // Add all these difference to get the total including wins and loses
    
        public int getOrderPricePerformance() {
        int sum = 0;
        for (OrderItem oi : orderitems) {
            sum = sum + oi.calculatePricePerformance();     //positive and negative values       
        }
        return sum;
    }
    public int getSalesVolume() {
        int sum = 0;
        for (OrderItem oi : orderitems) {
            sum = sum + oi.getQuantity() * oi.getActualPrice();     //positive and negative values       
        }
        return sum;
    }
        

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ProductCatalog getProductCatalog() {
        return productCatalog;
    }
    public Supplier getSupplier(){
        return getProductCatalog().getSupplier();
    
    }

    public ArrayList<OrderItem> getOrderitems() {
        return orderitems;
    }
    
    
    public void printProductsDetails3(){
        System.out.println("Product: " + this.name + " | Price Performance: " + this.getOrderPricePerformance());
        //System.out.println("Product: " + this.name +" --Floor Price: " + this.floorPrice + "| Target Price: " + this.targetPrice + "| Ceilling Price: " + this.ceilingPrice);
        //for (OrderItem oi: orderitems){
            //System.out.println("Sold - Order No: " + oi.getOrder().getOrderNo() + " Quantity: " + oi.getQuantity() + " Price: " + oi.getActualPrice());
        //}
    };

    public void printProductsDetails2(){
        System.out.println("Product: " + this.name + " | Sales Volume: " + this.getSalesVolume());
        //System.out.println("Product: " + this.name +" --Floor Price: " + this.floorPrice + "| Target Price: " + this.targetPrice + "| Ceilling Price: " + this.ceilingPrice);
        //for (OrderItem oi: orderitems){
            //System.out.println("Sold - Order No: " + oi.getOrder().getOrderNo() + " Quantity: " + oi.getQuantity() + " Price: " + oi.getActualPrice());
        //}
    };



    public void printProductsDetailsPP() {
        System.out.println("Product: " + this.name + " |Target Price: $" + this.getTargetPrice());
    }

    public void printProductsDetails() {
        System.out.println("Product: " + this.name + " | Sales Volume: " + this.getSalesVolume());
    }

    public void printProductDetail_so() {
        System.out.println("Product: " + this.name + " | Original Price: $" + this.getTargetPrice());    
    }

    
   
 
    

    
    
}
