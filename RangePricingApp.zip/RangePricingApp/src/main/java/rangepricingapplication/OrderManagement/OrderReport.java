/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.OrderManagement;

import java.util.ArrayList;
import rangepricingapplication.MarketModel.ChannelCatalog;
import rangepricingapplication.MarketModel.MarketCatalog;
import rangepricingapplication.ProductManagement.ProductSummary;

/**
 *
 * @author joyce
 */
public class OrderReport {

    ArrayList<OrderSummary> orderSummarylist;

    public OrderReport() {
      
    }
    
    public void addOrderSummary(OrderSummary os){
    orderSummarylist.add(os);
    }
    
    public OrderSummary getOrdersFromChannels(){
        OrderSummary currentorder = null;
        for (OrderSummary os: orderSummarylist){
           if(currentorder == null)currentorder = os; // initial step 
           else 
             if(os.getChannel()==currentorder.getChannel()){
             currentorder = os;             }                        }
        return currentorder;
    }
    
    public ArrayList<OrderSummary> getChannelOrder(){
        ArrayList<OrderSummary> channelOrderList = new ArrayList();
        OrderSummary currentorder = null;
        for (OrderSummary os: orderSummarylist){
           if(os.getChannel()==currentorder.getChannel()){
               channelOrderList.add(os);}         
    }
        return channelOrderList;
}}
