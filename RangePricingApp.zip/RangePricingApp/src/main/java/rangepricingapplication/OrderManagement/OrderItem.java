/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.OrderManagement;

import rangepricingapplication.ProductManagement.Product;
import rangepricingapplication.ProductManagement.SolutionOffer;

/**
 *
 * @author kal bugrara
 */
public class OrderItem {
    Order order;
    Product selectedproduct;
    int actualPrice;
    int quantity;
    SolutionOffer solutionOffer;
    
    /*public OrderItem(Product p, int q, Order o, int price) {
        selectedproduct = p;
        p.addOrderItem(this); //make sure product links back to the item
        quantity = q;
        order = o;
        actualPrice = price;
    }*/

    public OrderItem(SolutionOffer so) {
        solutionOffer = so;
        
    }

    
    public int getOrderItemTotal() {
        return solutionOffer.getPrice();
    }
    //returns positive if seller is making higher margin than target
    //returns negative if seller is making lower margin than target
    //otherwise zero meaning neutral
    
    public int calculatePricePerformance() {
        return solutionOffer.getPrice() - solutionOffer.getBasicPrice();
    }
    
   
    
    public boolean isActualAboveTarget(){
        if (actualPrice> selectedproduct.getTargetPrice()) return true;
        else return false;

}
    public boolean isActualBelowTarget(){
        if (actualPrice<selectedproduct.getTargetPrice()) return true;
        else return false;

}
        public boolean isActualATTarget(){
        if (actualPrice==selectedproduct.getTargetPrice()) return true;
        else return false;

}

    public Order getOrder() {
        return order;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getActualPrice() {
        return actualPrice;
    }
    
    public void printOrderItemDetails(){
        System.out.println("Product: "+ this.solutionOffer.getPrice());//+ " Quantity:" + this.quantity + " Price：" + this.actualPrice
        
    }
    
   
    
        
}
