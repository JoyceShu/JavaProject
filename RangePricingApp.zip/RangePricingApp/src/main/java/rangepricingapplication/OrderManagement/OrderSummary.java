/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.OrderManagement;
import rangepricingapplication.CustomerManagement.CustomerProfile;
import rangepricingapplication.MarketModel.Channel;
import rangepricingapplication.MarketModel.Market;

/**
 *
 * @author joyce
 */
public class OrderSummary {
    Order order; 
    int orderRevenue;
    Channel channel;
    Market market;
    CustomerProfile customer;

    public OrderSummary(Order o) {
        this.order = order;
        this.market = market;
        this.customer =o.getCustomer();
        int orderRevenue = o.getOrderTotal();
        this.channel = o.getChannel();
    }

    public int getOrderRevenue() {
        return orderRevenue;
    }
    
    public Channel getChannel() {
        return channel;
    }

    public Order getOrder() {
        return order;
    }

    public Market getMarket() {
        return market;
    }

    public CustomerProfile getCustomer() {
        return customer;
    }
    


}
