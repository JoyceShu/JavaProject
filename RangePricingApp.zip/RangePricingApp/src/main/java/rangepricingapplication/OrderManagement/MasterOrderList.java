/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.OrderManagement;

import java.util.ArrayList;
import rangepricingapplication.Business.Business;
import rangepricingapplication.CustomerManagement.CustomerProfile;
import rangepricingapplication.MarketModel.Channel;
import rangepricingapplication.Personnel.EmployeeProfile;

/**
 *
 * @author kal bugrara
 */
public class MasterOrderList {
    Business business;
    ArrayList<Order> orders;
    Channel channel;
 
    
    public MasterOrderList(Business business){
        orders = new ArrayList();
        this.business = business;
    }
    
    public Order newOrder(CustomerProfile cp,Channel c){
        Order o= new Order(cp,c,this);
        orders.add(o);
        channel = c;
        return o;
            
    }

    public Channel getChannel() {
        return channel;
    }

    public ArrayList<Order> getOrders() {
        return orders;
    }

    public Business getBusiness() {
        return business;
    }
    
    public void printOrders(){
        System.out.println("Printing Master Order List: ");
        for (Order o: orders)
            o.printOrderDetails();
    }

    public int getSalesVolume() {
        int sum = 0;
        for (Order o : orders) {
            sum = sum + o.getOrderTotal();
        }
        return sum;
            
    }

}
