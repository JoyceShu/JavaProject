/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.OrderManagement;

import java.util.ArrayList;
import rangepricingapplication.CustomerManagement.CustomerProfile;
import rangepricingapplication.MarketModel.Channel;
import rangepricingapplication.Personnel.EmployeeProfile;
import rangepricingapplication.ProductManagement.Product;
import rangepricingapplication.ProductManagement.SolutionOffer;

/**
 *
 * @author kal bugrara
 */
public class Order {
    MasterOrderList masterOrderList;
    ArrayList<OrderItem> orderitems;
    CustomerProfile customer;
    Channel channel;
 
    
    public Order(CustomerProfile cp, Channel c, MasterOrderList mol) {
        orderitems = new ArrayList();
        customer = cp;
        masterOrderList = mol;
        channel = c;
        customer.addCustomerOrder(this);
        
    }
    
    
     /*public Order(CustomerProfile cp) {
        orderitems = new ArrayList();
        customer = cp;
        customer.addCustomerOrder(this);
        //salesperson.addSalesOrder(this);
    }*/

    public Channel getChannel() {
        return channel;
    }


    
    /*public OrderItem newOrderItem(Product p, int q, int price) {
        OrderItem oi = new OrderItem(p, q, this, price);
        orderitems.add(oi);
        return oi;
    }*/

    public MasterOrderList getMasterOrderList() {
        return masterOrderList;
    }

    public ArrayList<OrderItem> getOrderitems() {
        return orderitems;
    }

    public CustomerProfile getCustomer() {
        return customer;
    }

    
    public int getOrderTotal() {
        int sum = 0;
        for (OrderItem oi : orderitems) {
            sum = sum + oi.getOrderItemTotal();
        }
        return sum;
    }

    public int getOrderPricePerformance() {
        int sum = 0;
        for (OrderItem oi : orderitems) {
            sum = sum + oi.calculatePricePerformance();     //positive and negative values       
        }
        return sum;
    }

    public int getNumberOfOrderItemsAboveTarget() {
        int sum = 0;
        for (OrderItem oi : orderitems) {
            if (oi.isActualAboveTarget() == true) {
                sum = sum + 1;
            }
        }
        return sum;
    }


    
    public void printOrderDetails(){
        //System.out.println("Order No: " + this.OrderNo);
        for (OrderItem oi: orderitems)
            oi.printOrderItemDetails();
    
    
    }

    public void printOrderDetails3() {
        System.out.println();
    }
    

    
    public OrderItem newOrderItem(SolutionOffer so) {
        OrderItem oi = new OrderItem(so);
        orderitems.add(oi);
        return oi;
    }
    


   
}
