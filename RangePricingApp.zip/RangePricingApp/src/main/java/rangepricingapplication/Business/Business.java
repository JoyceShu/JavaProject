/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.Business;

import rangepricingapplication.CustomerManagement.CustomerDirectory;
import rangepricingapplication.MarketModel.ChannelCatalog;
import rangepricingapplication.MarketModel.MarketCatalog;
import rangepricingapplication.OrderManagement.MasterOrderList;
import rangepricingapplication.Personnel.EmployeeDirectory;
import rangepricingapplication.ProductManagement.SolutionOfferCatalog;
import rangepricingapplication.Supplier.SupplierDirectory;

/**
 *
 * @author kal bugrara
 */
public class Business {
    String name;
    SupplierDirectory supplierDirectory;
    MasterOrderList masterOrderList;
    CustomerDirectory customerDirecotory;
    EmployeeDirectory employeeDirectory;
    MarketCatalog marketCatalog;
    ChannelCatalog channelCatalog;
    //SolutionOfferCatalog solutionOfferCatalog;
    
            
            
    public Business(String name){
        this.name = name;
        this.supplierDirectory = new SupplierDirectory(this);
        this.masterOrderList = new MasterOrderList(this);
        this.employeeDirectory = new EmployeeDirectory(this);
        //this.customerDirecotory = new CustomerDirectory(this);
        this.marketCatalog = new MarketCatalog(this);
        this.channelCatalog = new ChannelCatalog(this);
        //this.solutionOfferCatalog = new SolutionOfferCatalog(this);


    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public SupplierDirectory getSupplierDirectory() {
        return supplierDirectory;
    }


    public MasterOrderList getMasterOrderList() {
        return masterOrderList;
    }

    public CustomerDirectory getCustomerDirecotory() {
        return customerDirecotory;
    }

    public EmployeeDirectory getEmployeeDirecotory() {
        return employeeDirectory; 
    }

    public MarketCatalog getMarketCatalog() {
        return marketCatalog;
    }


    public ChannelCatalog getChannelCatalog() {
        return channelCatalog;
    }



    public int getSalesVolume() {
        return masterOrderList.getSalesVolume();
    }



}