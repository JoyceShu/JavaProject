/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.CustomerManagement;

import rangepricingapplication.Personnel.*;
import java.util.ArrayList;
import java.util.Random;
import rangepricingapplication.Business.*;
import rangepricingapplication.Supplier.Supplier;

/**
 *
 * @author kal bugrara
 */
public class CustomerDirectory {

    Business business;
    ArrayList<CustomerProfile> customerlist;
    

    public CustomerDirectory(Business business) {

        this.business = business;
        customerlist = new ArrayList();

    }

    public Business getBusiness() {
        return business;
    }

    public CustomerProfile findCustomer(String id) {

        for (CustomerProfile cp : customerlist) {

            if (cp.isMatch(id)) {
                return cp;
            }
        }
            return null; //not found after going through the whole list
         }



    public CustomerProfile getRandomCustomer() {
        if (customerlist.size() == 0) return null;
        CustomerProfile randomCustomer;
        Random r = new Random();
        int randomIndex = r.nextInt(customerlist.size());
        randomCustomer = customerlist.get(randomIndex);
        return randomCustomer;

    }
    
    
}
