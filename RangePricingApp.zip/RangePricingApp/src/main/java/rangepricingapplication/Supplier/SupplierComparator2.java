/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.Supplier;

import java.util.Comparator;

/**
 *
 * @author joyce
 */
 public class SupplierComparator2 implements Comparator<Supplier> {
   

    @Override
    public int compare(Supplier o1, Supplier o2) {
        return Integer.compare(o1.getProductcatalog().getSaleVolme(),o2.getProductcatalog().getSaleVolme());
    }


}