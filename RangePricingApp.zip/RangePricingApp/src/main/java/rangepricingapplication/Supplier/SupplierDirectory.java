/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.Supplier;

import java.util.ArrayList;
import java.util.Random;
import rangepricingapplication.Business.Business;

/**
 *
 * @author kal bugrara
 */
public class SupplierDirectory {
    Business business;
    ArrayList<Supplier> suppliers;
    
    
    public SupplierDirectory(Business business){
        suppliers = new ArrayList();
        this.business = business;
    }

    public Business getBusiness() {
        return business;
    }

    
    public Supplier newSupplier(String n){
        Supplier supplier = new Supplier(n);
        suppliers.add(supplier);
        return supplier;

    }
    public void printSupplier(){
        for (Supplier s: suppliers){
            s.printSupplierDetails();
        
        }
    }

    public ArrayList<Supplier> getSuppliers() {
        return suppliers;
    }
      

    
    public Supplier getRandomSupplier(){
        if (suppliers.size() == 0) return null;
        Supplier randomSupplier;
        Random r = new Random();
        int randomIndex = r.nextInt(suppliers.size());
        randomSupplier = suppliers.get(randomIndex);
        return randomSupplier;
    }
    public Supplier getAllSupplier(){
        if (suppliers.size() == 0) return null;
        Supplier AllSupplier;
        //Random r = new Random();
        int randomIndex = 30;
        AllSupplier = suppliers.get(randomIndex);
        return AllSupplier;
    }
      }
