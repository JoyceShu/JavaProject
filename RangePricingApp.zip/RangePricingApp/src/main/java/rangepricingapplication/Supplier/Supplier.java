/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.Supplier;

import java.util.ArrayList;
import java.util.Random;
import rangepricingapplication.OrderManagement.Order;
import rangepricingapplication.ProductManagement.Product;
import rangepricingapplication.ProductManagement.ProductCatalog;
import rangepricingapplication.ProductManagement.ProductSummary;
import rangepricingapplication.ProductManagement.ProductsReport;

/**
 *
 * @author kal bugrara
 */
public class Supplier {
    SupplierDirectory directory;
    String name;
    ProductCatalog productcatalog;
    
    
    public Supplier(String n){
        name = n;
        productcatalog = new ProductCatalog(this);
        productcatalog.generatPerformanceReport();
    
    }
    public ProductSummary getTopProductAvoveTarger(){
        ProductsReport pr = productcatalog.generatPerformanceReport();
        ProductSummary ps  = pr.getTopProductAboveTarget();
        return ps;
    }

    public SupplierDirectory getDirectory() {
        return directory;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ProductCatalog getProductcatalog() {
        return productcatalog;
    }

   
    public void printSupplierDetails(){
        System.out.println("===========================================");
        System.out.println("===== Supplier: " + this.name);
        System.out.println("===========================================");
        this.productcatalog.printProducts();
    
    
    }
 

    //public ProductSummary getTopProductAboveTarget(){
        //ProductsReport pr_top = productcatalog.generatPerformanceReport();
        //ProductSummary ps_top = pr_top.getTopProductAboveTarget();
        //return ps_top;
        
    //}
    
   

    
}
