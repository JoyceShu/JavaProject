/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.Personnel;

import java.util.ArrayList;
import rangepricingapplication.Business.*;

/**
 *
 * @author kal bugrara
 */
public class EmployeeDirectory {

    Business business;
    ArrayList<EmployeeProfile> employeelist;

    public EmployeeDirectory(Business business) {

        this.business = business;
        employeelist = new ArrayList();

    }
    public ArrayList<EmployeeProfile> getEmployees() {
        return employeelist;
    }

    public Business getBusiness() {
        return business;
    }

    public EmployeeProfile newEmployeeProfile(String en) {

        EmployeeProfile sp = new EmployeeProfile(en, this);
        employeelist.add(sp);
        return sp;
    }

    public EmployeeProfile findEmployee(String id) {

        for (EmployeeProfile sp : employeelist) {

            if (sp.isMatch(id)) {
                return sp;
            }
        }
            return null; //not found after going through the whole list
         }

    public EmployeeProfile newEmployeProfile(String fullName) {
        EmployeeProfile sp = new EmployeeProfile(fullName, this);
        employeelist.add(sp);
        return sp;
    }


}
