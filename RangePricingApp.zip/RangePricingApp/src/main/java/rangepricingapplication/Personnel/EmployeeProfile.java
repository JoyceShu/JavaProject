/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.Personnel;

import java.util.ArrayList;
import rangepricingapplication.OrderManagement.Order;
import rangepricingapplication.OrderManagement.OrderItem;

/**
 *
 * @author kal bugrara
 */
public class EmployeeProfile {
    
    EmployeeDirectory employeeDirectory;
    Person person;
    ArrayList<Order> orders;
    String name;


    public EmployeeProfile(String en,EmployeeDirectory ed) {
        employeeDirectory = ed;
        name = en;
        orders = new ArrayList();
       
    }

    public String getName() {
        return name;
    }
   
        

    public EmployeeDirectory getEmployeeDirectory() {
        return employeeDirectory;
    }

    public void setEmployeeDirectory(EmployeeDirectory employeeDirectory) {
        this.employeeDirectory = employeeDirectory;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public ArrayList<Order> getOrders() {
        return orders;
    }
    
    

    public void setOrders(ArrayList<Order> orders) {
        this.orders = orders;
    }
    
    

    public boolean isMatch(String id) {
        if (person.getPersonId().equals(id)) {
            return true;
        }
        return false;
    }
      public void addSalesOrder(Order o){
        orders.add(o);
    }
     
     public int getSaleVolme() {
        int sum = 0;
        for (Order o : orders) {
            sum = sum + o.getOrderTotal();     //positive and negative values       
        }
        return sum;
    }
     public int getOrderPricePerformance() {
        int sum = 0;
        for (Order o : orders) {
            sum = sum + o.getOrderPricePerformance();     //positive and negative values       
        }
        return sum;
    }




}
