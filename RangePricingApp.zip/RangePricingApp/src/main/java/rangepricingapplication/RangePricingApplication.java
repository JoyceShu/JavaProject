package rangepricingapplication;

import com.github.javafaker.Company;
import com.github.javafaker.Faker;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;
import java.util.StringTokenizer;
import rangepricingapplication.Business.Business;
import rangepricingapplication.CustomerManagement.CustomerDirectory;
import rangepricingapplication.CustomerManagement.CustomerProfile;
import rangepricingapplication.MarketModel.Channel;
import rangepricingapplication.MarketModel.ChannelCatalog;
import rangepricingapplication.MarketModel.Market;
import rangepricingapplication.MarketModel.MarketCatalog;
import rangepricingapplication.MarketModel.MarketChannelAssignment;
import rangepricingapplication.OrderManagement.MasterOrderList;
import rangepricingapplication.OrderManagement.Order;
import rangepricingapplication.OrderManagement.OrderItem;
import rangepricingapplication.Personnel.EmployeeComparator1;
import rangepricingapplication.Personnel.EmployeeComparator2;
import rangepricingapplication.Personnel.EmployeeDirectory;
import rangepricingapplication.Personnel.EmployeeProfile;
import rangepricingapplication.Personnel.Person;
import rangepricingapplication.ProductManagement.Product;
import rangepricingapplication.ProductManagement.ProductCatalog;
import rangepricingapplication.ProductManagement.ProductComparator;
import rangepricingapplication.ProductManagement.ProductComparator2;
import rangepricingapplication.ProductManagement.ProductSummaryComparator;
import rangepricingapplication.ProductManagement.ProductSummary;
import rangepricingapplication.ProductManagement.ProductSummaryComparator;
import rangepricingapplication.ProductManagement.ProductsReport;
import rangepricingapplication.ProductManagement.SolutionOffer;
import rangepricingapplication.ProductManagement.SolutionOfferCatalog;
import rangepricingapplication.Supplier.Supplier;
import rangepricingapplication.Supplier.SupplierComparator1;
import rangepricingapplication.Supplier.SupplierComparator2;
import rangepricingapplication.Supplier.SupplierDirectory;

/**
 *
 * @author kal bugrara
 */
public class RangePricingApplication {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {

        //creating one business & linking classes
        Business BurgerKing = new Business("Burger King");
        MasterOrderList mol = BurgerKing.getMasterOrderList();
        //CustomerDirectory cd = BurgerKing.getCustomerDirecotory();
        
        //business ->marketcatalog
        //1. ManageProducts 
        //creating Market Catalog & ChannelCatalog link them to the business 
        MarketCatalog mrkCatalog = BurgerKing.getMarketCatalog();
        
        //marketcatalog -> market 
        //System.out.println("------------------------------------------------------------------------------------------");
        //-creating three markets by geograpy
        System.out.println("Burger King only serves following countries:");
        Market mrkUS = mrkCatalog.newMarket("USA");
        Market mrkCHN = mrkCatalog.newMarket("China");
        Market mrkJP = mrkCatalog.newMarket("Japan");
        mrkCatalog.printAllMarkets();//a list of markets 
        
        // market -> solutionOfferCatalog
        // -generate solution offers for 3 markets
        //SolutionOfferCatalog soCatalog = BurgerKing.getSolutionOfferCatalog();
        
        SolutionOfferCatalog soCatalog_us =  mrkUS.newSolutionOfferCatalog();
        SolutionOfferCatalog soCatalog_china =  mrkCHN.newSolutionOfferCatalog();
        SolutionOfferCatalog soCatalog_japan =  mrkJP.newSolutionOfferCatalog(); 
        
        // Solution OfferCatalog ->  solutionoffer without channel
        SolutionOffer soUS = soCatalog_us.newSolutionOffer(mrkUS, 5, null);//append market and initial price for combo
        SolutionOffer soCHN = soCatalog_china.newSolutionOffer(mrkCHN, 4, null);
        SolutionOffer soJP = soCatalog_japan.newSolutionOffer(mrkJP, 5, null);
     
        //creating some products
        //original price 
        Product coke = new Product("Coke",2, 3, 5);
        Product beefBurger = new Product("Beef Burger",7, 8, 10);
        Product chickenBurger = new Product("Chicken Burger", 6, 7, 8);
        Product greenTea = new Product("Green Tea", 3, 4, 5);
        
        //adjasting product price for different markets
        // a. adjasted price for us
        Product cokeUS = coke.updateProduct(2, 4, 5);
        Product beefBurgerUS = beefBurger.updateProduct(9, 10, 11);
        
        //b. adjating price for china
        Product cokeCHN = coke.updateProduct(1, 2, 3);
        Product chickenBurgerCHN = chickenBurger.updateProduct(7, 8, 9);

        // c. adjasting price for japan
        Product cokeJP = coke.updateProduct(2, 3, 4);
        Product beefBurgerJP = beefBurger.updateProduct(9, 10, 12);
        

        //print all products
  
        System.out.println("------------------------------------------------------------------------------------------");
        
        //-building solutionoffer & bundle products -> adding products to solution offer
        soUS.addProduct(cokeUS, beefBurgerUS);
        soCHN.addProduct(cokeCHN, chickenBurgerCHN);
        soJP.addProduct(greenTea,beefBurgerJP); // green tea only offer in Japan
    
        //solution offer with channel
        
        //printing all product for each solution offers
        System.out.println("Burger King is offering following products as a combo choice: (USA)");
        soUS.printSolutionOfferDetail(); //print target price as orginal prices
        System.out.println();
        System.out.println("Burger King is offering following products as a combo choice: (China)");
        soCHN.printSolutionOfferDetail();
        System.out.println();
        System.out.println("Burger King is offering following products as a combo choice: (Japan)");
        soJP.printSolutionOfferDetail(); 
      

        // 2. Manage Pricing of Products
        //-adjusting pricing by needs
        // -creating new channel and assignment channel to market
        //1. CHINA- TV and Email 
        //2. USA - ALL 3 
        //3. JP - tv and youtube
        System.out.println("------------------------------------------------------------------------------------------");
        //creating a channel catalog
        ChannelCatalog channelCatalog = BurgerKing.getChannelCatalog();
        
        Channel youtube = channelCatalog.newChannel("Youtube", channelCatalog);
        Channel tv = channelCatalog.newChannel("TV", channelCatalog); //middle
        Channel email = channelCatalog.newChannel("Email", channelCatalog);//lowest
     
        System.out.println("Burger King has following channels: ");
        channelCatalog.printAllChannelsDetail();
        
        //usa
        MarketChannelAssignment mca_Email = new MarketChannelAssignment(mrkUS, email); // *1
        MarketChannelAssignment mca_TV = new MarketChannelAssignment(mrkUS, tv); //* 2
        MarketChannelAssignment mca_Youtube = new MarketChannelAssignment(mrkUS, youtube); // *3
      
        //mutiplier index by market**channel
        int PriceChange_TV  = mca_TV.getPriceChangeForMCA(2);
        int PriceChange_Email  = mca_Email.getPriceChangeForMCA(1);
        int PriceChange_Youtube  = mca_Youtube.getPriceChangeForMCA(3);
        
        //orginal price for each solutionoffer
        int PriceSoUS = soUS.getPrice();
        int PriceSoCHN = soCHN.getPrice(); 
        int PriceSoJP = soJP.getPrice();
   
        //adjasting pricing by market & channel
        //1) USA
        SolutionOffer soUSemail = soCatalog_us.newSolutionOffer(mrkUS, PriceSoUS * PriceChange_Email, email);
        SolutionOffer soUStv = soCatalog_us.newSolutionOffer( mrkUS,PriceSoUS * PriceChange_TV,tv);// 2
        SolutionOffer soUSyoutube =soCatalog_us.newSolutionOffer(mrkUS,PriceSoUS * PriceChange_Youtube,youtube);//3 
        soUSemail.setBasicPrice(3);
        soUStv.setBasicPrice(5);
        soUSyoutube.setBasicPrice(6);


        //2)CHINA
        SolutionOffer soCHNtv =soCatalog_china.newSolutionOffer(mrkCHN,PriceSoCHN * PriceChange_TV, tv) ;//4 
        SolutionOffer soCHNemail =soCatalog_china.newSolutionOffer(mrkCHN,PriceSoCHN * PriceChange_Email, email );//5
        soCHNtv.setBasicPrice(4);
        soCHNemail.setBasicPrice(3);
        
        //3)Japan
        SolutionOffer soJPtv = soCatalog_japan.newSolutionOffer(mrkJP,PriceSoJP * PriceChange_TV, tv);//6 
        SolutionOffer soJPyoutube = soCatalog_japan.newSolutionOffer(mrkUS,PriceSoJP * PriceChange_Youtube, youtube);//7
        soJPtv.setBasicPrice(4);
        soJPyoutube.setBasicPrice(6);
 
        
       // 3.  User Interface
       System.out.println("------------------------------------------------------------------------------------------");
       Scanner scanner = new Scanner(System.in);
       System.out.println("Where are you come from? Which is your channel to access our product?");
       System.out.println("1. USA - TV");
       System.out.println("2. USA - Email");
       System.out.println("3. USA - Youtube");
       
       System.out.println("4. China - TV ");
       System.out.println("5. China - Email ");

       System.out.println("6. Japan - TV");
       System.out.println("7. Japan - Youtube");

       System.out.println("Please enter chioce from 1, 2, 3, 4, 5, 6, 7 : ");
       int choice = scanner.nextInt();
       
       System.out.println("Your Choices are: ");
       System.out.println("Number: " + choice);
        
       if (choice == 1) {
           System.out.println("Combo: Beef Burger with Coke " + " | Original Price: $" + (cokeUS.getTargetPrice()+beefBurgerUS.getTargetPrice())); //$15
           System.out.println("Your Price: $" +  soUSemail.getPrice());//$10
       } else if (choice == 2) {
           System.out.println("Combo: Beef Burger with Coke " + " | Original Price: $" + (cokeUS.getTargetPrice()+beefBurgerUS.getTargetPrice())); //$15
           System.out.println("Your Price: $" +  soUStv.getPrice());//$5
       } else if(choice == 3) {
           System.out.println("Combo: Beef Burger with Coke " + " | Original Price: $" + (cokeUS.getTargetPrice()+beefBurgerUS.getTargetPrice())); //$15
           System.out.println("Your Price: $" +  soUSyoutube.getPrice());//$15
       } else if(choice == 4) {
           System.out.println("Combo: Chicken Burger with Coke " + " | Original Price: $" + (cokeCHN.getTargetPrice()+chickenBurgerCHN.getTargetPrice())); //$13
           System.out.println("Your Price: $" +  soCHNtv.getPrice());//$8
       } else if(choice == 5) {
           System.out.println("Combo: Chicken Burger with Coke " + " | Original Price: $" + (cokeCHN.getTargetPrice()+chickenBurgerCHN.getTargetPrice())); //$13
           System.out.println("Your Price: $" + soCHNemail.getPrice());//$4
       } else if(choice == 6) {
           System.out.println("Combo: Beef Burger with Grean Tea" + " | Original Price: $" + (greenTea.getTargetPrice()+beefBurgerJP.getTargetPrice())); //$17
           System.out.println("Your Price: $" +  soJPtv.getPrice());//
       } else if(choice == 7) {
           System.out.println("Combo: Beef Burger with Green Tea " + " | Original Price: $" + (greenTea.getTargetPrice()+beefBurgerJP.getTargetPrice())); //$17
           System.out.println("Your Price: $" + soJPyoutube.getPrice());//$15
       } else  {
           System.out.println("Invalid Input. Please enter your choice again.");
       }
       
       //4. Peformance Assessment
       //creating orders from US market
      for (int c = 0; c < 40; c++){
            CustomerProfile cp = mrkUS.newCustomerProfile(); 
            Order orderUSA = mol.newOrder(cp,youtube);
            OrderItem oi = orderUSA.newOrderItem(soUSyoutube);
            soUSyoutube.addOrderItem(oi);
            youtube.addOrderItem(oi);
            mrkUS.addOrderItem(oi);
            cp.addCustomerOrder(orderUSA);   
        }
       for (int c = 0; c < 30; c++){
            CustomerProfile cp = mrkUS.newCustomerProfile();
            Order orderUSA = mol.newOrder(cp,tv);
            OrderItem oi = orderUSA.newOrderItem(soUStv);
            soUStv.addOrderItem(oi);
            tv.addOrderItem(oi);
            mrkUS.addOrderItem(oi);
            cp.addCustomerOrder(orderUSA);  
        }
   
        for (int c = 0; c < 30; c++){
            CustomerProfile cp = mrkUS.newCustomerProfile();
            Order orderUSA = mol.newOrder(cp,email);
            OrderItem oi = orderUSA.newOrderItem(soUSemail);
            soUSemail.addOrderItem(oi);
            email.addOrderItem(oi);
            mrkUS.addOrderItem(oi);
            cp.addCustomerOrder(orderUSA);  
        }
        
        //creating orders from China Market

       for (int c = 0; c < 80; c++){
            CustomerProfile cp = mrkCHN.newCustomerProfile();
            Order orderCHN = mol.newOrder(cp,tv);
            OrderItem oi = orderCHN.newOrderItem(soCHNtv);
            soCHNtv.addOrderItem(oi);
            tv.addOrderItem(oi);
            mrkCHN.addOrderItem(oi);
            cp.addCustomerOrder(orderCHN);  
        }
       
        for (int c = 0; c < 200; c++){
            CustomerProfile cp = mrkUS.newCustomerProfile();
            Order orderCHN = mol.newOrder(cp,email);
            OrderItem oi = orderCHN.newOrderItem(soCHNemail);
            soCHNemail.addOrderItem(oi);
            email.addOrderItem(oi);
            mrkCHN.addOrderItem(oi);
            cp.addCustomerOrder(orderCHN);  
        }
        
        //creating orders from Japan Market
        for (int c = 0; c < 30; c++){
            CustomerProfile cp = mrkJP.newCustomerProfile();
            Order orderJP = mol.newOrder(cp,tv);
            OrderItem oi = orderJP.newOrderItem(soJPtv);
            soJPtv.addOrderItem(oi);
            tv.addOrderItem(oi);
            mrkJP.addOrderItem(oi);
            cp.addCustomerOrder(orderJP);  
        }
   
        for (int c = 0; c < 40; c++){
            CustomerProfile cp = mrkJP.newCustomerProfile();
            Order orderJP = mol.newOrder(cp,youtube);
            OrderItem oi = orderJP.newOrderItem(soJPyoutube);
            soJPyoutube.addOrderItem(oi);
            youtube.addOrderItem(oi);
            mrkJP.addOrderItem(oi);
            cp.addCustomerOrder(orderJP);  
        } 
        
        
        System.out.println("------------------------------------------------------------------------------------------");
        
        System.out.println("Performace Report - Channel & Makert");
        System.out.println("------------------------------------------------------------------------------------------");
        System.out.println("Burger King - Total Sales Revenue (all markets) : $" + BurgerKing.getSalesVolume()); //total revenues from 3 markets
        System.out.println("------------------------------------------------------------------------------------------");
        System.out.println("Sales Volumes - TV ; $" + tv.getSalesVolume());
        System.out.println("Sales Volumes - Yotube ; $" + youtube.getSalesVolume());
        System.out.println("Sales Volumes - Email ; $" + email.getSalesVolume());
        System.out.println("------------------------------------------------------------------------------------------");
        System.out.println("Profits - Yotube ; $" + youtube.getOrderPricePerformance());
        System.out.println("Profits - TV ; $" + tv.getOrderPricePerformance());
        System.out.println("Profits - Email ; $" + email.getOrderPricePerformance());
        System.out.println("------------------------------------------------------------------------------------------");
        System.out.println("Sales Volumes - China ; $" + mrkCHN.getSalesVolume());
        System.out.println("Sales Volumes - US ; $" + mrkUS.getSalesVolume());
        System.out.println("Sales Volumes - Japan ; $" + mrkJP.getSalesVolume());
        System.out.println("------------------------------------------------------------------------------------------");
        System.out.println("Profits - US ; $" + mrkUS.getOrderPricePerformance());
        System.out.println("Profits - Japan ; $" + mrkJP.getOrderPricePerformance());
        System.out.println("Profits - China ; $" + mrkCHN.getOrderPricePerformance());
        System.out.println("------------------------------------------------------------------------------------------");
        
     

    }}