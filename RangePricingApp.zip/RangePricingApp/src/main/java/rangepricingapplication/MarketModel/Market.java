/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.MarketModel;

import java.util.ArrayList;
import rangepricingapplication.CustomerManagement.CustomerProfile;
import rangepricingapplication.OrderManagement.MasterOrderList;
import rangepricingapplication.OrderManagement.OrderItem;
import rangepricingapplication.ProductManagement.SolutionOffer;
import rangepricingapplication.ProductManagement.SolutionOfferCatalog;
import rangepricingapplication.ProductManagement.SolutionReport;

/**
 *
 * @author kal bugrara
 */
public class Market {
    //ArrayList<MarketChannelAssignment> channels;
    ArrayList<SolutionOffer> solist;
    ArrayList<String> characteristics; 
    int size;
    private int salesrevenus;
    CustomerProfile cp;
    MasterOrderList morc;
    MarketCatalog mrkCatalog;
    SolutionOfferCatalog soCatalog;
    ArrayList<CustomerProfile> customerlist;
    ArrayList<OrderItem> orderitems;
 
    
public Market(String s){
    characteristics = new ArrayList();
    customerlist = new ArrayList();
    characteristics.add(s);
    customerlist.add(cp);
   // soCatalog = new SolutionOfferCatalog(this);
    orderitems = new ArrayList();
}


    public SolutionOfferCatalog newSolutionOfferCatalog() {
        SolutionOfferCatalog soCatalog = new SolutionOfferCatalog();
        //solist.add(soCatalog);
        SolutionOfferCatalog soCatlog;
        return soCatalog;
    }
    
/*  public Product getSalesRevenus(){
        SolutionReport sr = soCatalog.gernarateSalesReveuneReport();
        
    } */
    
    public void addOrderItem(OrderItem oi){
        orderitems.add(oi);
    }
    
   public int getSalesVolume() {
        int sum = 0;
        for (OrderItem oi : orderitems) {
            sum = sum + oi.getOrderItemTotal();
        }
        return sum;
            
    }
   public int getOrderPricePerformance(){
        int sum = 0;
        for (OrderItem oi: orderitems){
            sum = sum + oi.calculatePricePerformance();
        }
         return sum;
    }


    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }


    public CustomerProfile getCp() {
        return cp;
    }

    public MarketCatalog getMrkCatalog() {
        return mrkCatalog;
    }


    public void printMarketsDetails() {
        System.out.println("Market: " + this.characteristics);
    }

    public CustomerProfile newCustomerProfile() {
        CustomerProfile cp = new CustomerProfile();
        customerlist.add(cp);
        return cp;
    }
    
    


}
