/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.MarketModel;

import java.util.ArrayList;
import rangepricingapplication.OrderManagement.Order;
import rangepricingapplication.OrderManagement.OrderItem;
import rangepricingapplication.OrderManagement.OrderReport;
/**
 *
 * @author kal bugrara
 */
public class Channel {
    Market market;
    ChannelCatalog channelCatalog;
    String name;
    Order order;
    OrderReport or;
    ArrayList<Order> orders;
    int totalRevenue;
    ArrayList<OrderItem> orderitems;
 
    public Channel(String name, ChannelCatalog cc) {
        this.name = name;
        channelCatalog = cc;
        orderitems = new ArrayList();
       
    }

    public Market getMarket() {
        return market;
    }

    public String getName() {
        return name;
    }
    
    public void addOrderItem(OrderItem oi){
        orderitems.add(oi);
    }

    public ChannelCatalog getChannelCatalog() {
        return channelCatalog;
    }

    public void printChannel() {
        System.out.println("Channel: " + this.name);
    }
    public int getSalesVolume() {
        int sum = 0;
        for (OrderItem oi : orderitems) {
            sum = sum + oi.getOrderItemTotal();
        }
        return sum;
            
    }
    
    public int getOrderPricePerformance(){
        int sum = 0;
        for (OrderItem oi: orderitems){
            sum = sum + oi.calculatePricePerformance();
        }
         return sum;
    }


    
    /*
    public OrderReport generatOrderPerformanceReport(){
        OrderReport or = new OrderReport();
        for(Order o: order){
            OrderSummary os = new ProductSummary(o);
            or.addProductSummary(os);
        }
        return or; 
    }  
     */

    }

    
