/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.MarketModel;

import java.util.ArrayList;
import rangepricingapplication.Business.Business;
import rangepricingapplication.OrderManagement.Order;

/**
 *
 * @author joyce
 */
public class ChannelCatalog {
    Business business;
    ArrayList <Channel> channellist;
    Order order;
    

    
    public ChannelCatalog(Business business) {
        this.business = business;
        this.order = order;
        channellist = new ArrayList();
        
    }
    
    public Business getBusiness() {
        return business;
    }

    public Channel newChannel(String name, ChannelCatalog cc) {
        Channel c = new Channel(name,this);
        channellist.add(c);
        return c;
    }

    public ArrayList<Channel> getChannellist() {
        return channellist;
    }


    public void printAllChannelsDetail() {
        for (Channel channel: channellist){
            channel.printChannel();
    }}
    
    
    
    
    

    }
