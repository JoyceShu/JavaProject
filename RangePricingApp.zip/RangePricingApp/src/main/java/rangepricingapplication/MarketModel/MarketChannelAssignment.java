/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rangepricingapplication.MarketModel;

/**
 *
 * @author kal bugrara
 */
public class MarketChannelAssignment {
    
    Market market;
    Channel channel;
    
    public MarketChannelAssignment(Market m, Channel c){
        market = m;
        channel = c;
    }

    public Market getMarket() {
        return market;
    }

    public void setMarket(Market market) {
        this.market = market;
    }

    public Channel getChannel() {
        return channel;
    }

    public void setChannel(Channel channel) {
        this.channel = channel;
    }
    
    public int getPriceChangeForMCA(int PriceChange) {
        int initial = 0;
        PriceChange = initial + PriceChange;
        return PriceChange;
        }
    
    
}
